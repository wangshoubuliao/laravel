<?php

namespace App\Http\Controllers\user;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    public function index(request $request){
       
        $users=DB::table('category')->get();
       
        return view('user.user', ['users' => $users]);
    }
    public function doadd(Request $request){
        $data=$request->input();
        // print_r($data);die;
        $res=DB::table('user')->insert($data);
        if($res){
            echo 1;
        }else{
            echo 2;
        }
    }
    public function show(Request $request){
        // $users=DB::table('user')->get();
        $users = DB::table('user')->join('category','category.cata_id','=','user.category')->paginate(4);
        
        return view('user.show', ['users' => $users]);
    }
    public function delect(Request $Request){
        $id=$Request->input('id');
        // echo $id;
        $res=DB::table('user')->where('id',$id)->delete();
        if($res){
            echo 1;
        }else{
            echo 2;
        }
    }
    public function update(Request $Request){
        $id=$Request->input('id');
        // echo $id;die;
        $users=DB::table('category')->get();
        $user=DB::table('user')->where('id',$id)->get();
        // print_r($user);die;
        return view('user.update', ['users' => $users,'user' => $user]);
    }
    public function doupdate(Request $request){
        $id=$request->input('id');
        $date=$request->input();
        $res=DB::table('user')->where('id',$id)->update($date);
        if($res){
            echo 1;
        }else{
            echo 2;
        }
    }
    public function up(Request $request){
        $id=$request->input('id');
        
    }
}
