<?php

namespace App\Http\Controllers\haitao;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
class IndexController extends Controller
{
    //
    public static $arrCate=[];
    public function index(){
        $user=DB::table('goods')->where('goods_up',1)->paginate(2);
        // print_r($user);
        return view('haitao.index',['users' => $user]);
    }
    public function userpage(){
        return view('haitao.userpage');
    }
  
    public function box(Request $request){
        $page=$request->input('page');
        $pageNum=4;
        $offset=($page-1)*$pageNum;
        $pageTotal=DB::table('goods')->count();
        $toPage=ceil($pageTotal/$pageNum);
        $users = DB::table('goods')->offset($offset)->limit($pageNum)->get();
        $objview= view('haitao.box',['users'=>$users]);
        $content=response($objview)->getContent();
        $arr['info']=$content;
        $arr['page']=$toPage;
        return $arr;
    } 
    public function allshop(Request $request){
        $user=DB::table('cate')->where('pid',0)->get();
        $page=$request->input('page',0); 
        $pageNum=4;
        $offset=($page)*$pageNum;
        $users=DB::table("goods")->offset($offset)->limit($pageNum)->get();
        return view('haitao.allshop',['user'=>$user,'users'=>$users]);
    }
    public function goods(Request $request){
        $cate=$request->input('cate'); 
        $page=$request->input('page',0); 
        $pageNum=4;
        $offset=($page)*$pageNum;
        if($cate==0){
            $user=DB::table("goods")->offset($offset)->limit($pageNum)->get();
            $pageTotal=DB::table('goods')->count();
        }else{
            // $cate_id=$request->input('cate_id');
    //        echo $cate_id;die;
            
            // $arrIds=DB::table('cate')->select('cate_id')->where('pid',0)->get();
            $this->get($cate);
            
           $cate_id=self::$arrCate;
            // $users=DB::table("cate")->get();
            // $cateid=$this->getid($users,$cate);
            $user=DB::table('goods')->whereIn('cate_id',$cate_id)->offset($offset)->limit($pageNum)->get();
            $pageTotal=DB::table('goods')->where('cate_id',$cate_id)->count();
        }
        // $users = DB::table('goods')->offset($offset)->limit($pageNum)->get();
        $toPage=ceil($pageTotal/$pageNum);
        $objview= view('haitao.goods',['users'=>$user]);
        $content=response($objview)->getContent();
        $arr['info']=$content;
        $arr['page']=$toPage;
        return $arr;
    }
    // public function getid($users, $cate){
    //     $cate='';
    //     foreach($users  as $v){
    //         if($v->pid==$cate){
    //             $cid=$v->cate_id;
    //             $this->getid($users,$cid);
    //             $cate.=$v->cate_id.',';
    //         }
    //     }
    //     echo $cate;die;
    // }
    
    
    /**
         * 获取分类的id
         * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|\thinkesponse\View
         */
        private  function get($id){
                $arrIds=DB::table('cate')->select('cate_id')->where('pid',$id)->get();
                if(count($arrIds)>0){
                    foreach($arrIds as $k=>$v){
                        $cateId=$v->cate_id;
                        $arrNews=$this->get($cateId);
                    }
                }
                foreach($arrIds as $v){
                    $cate_id=$v->cate_id;
    
    
                    array_push(self::$arrCate,$cate_id);
                }
            }
    public function show(Request $request){
        $goods_id=$request->input('goods_id');
        $arr=DB::table('goods')->where('goods_id',$goods_id)->first();
        $id = $request->session()->get('id');
        $caCount= DB::table('cart')->where('user_id',$id)->select('number')->get();
            $num=[];
        foreach($caCount as $k=>$v){
                $num[]=$v->number;
            }
            $count=array_sum($num);
        return view('haitao.show',['arr'=>$arr,'count'=>$count]);
    }
    public function cart(Request $request){
        $id = $request->session()->get('id');
        $where=[
            'user_id'=>$id,
            'status'=>1
        ];
        $arr=DB::table('cart')->join('goods','goods.goods_id','=','cart.goods_id')->where($where)->get();
        $user=DB::table('goods')->where('goods_hot',1)->offset(0)->limit(4)->get();
        return view('haitao.cart',['arr'=>$arr,'user'=>$user]);
    }
   
    public function upcart(Request $request){
        $cart_id=$request->input('id');
        $num=$request->input('num');
        // echo $cart_id;die;
        if($num<=0){
            DB::table('cart')->where('cart_id',$cart_id)->update(['number'=>1]);
            echo json_encode([
                'msg'=>0,
                'font'=>'不可输入负数',
                'count'=>'1'
            ]);die;
        }
        
        $goods_id=$request->input('goods');
        $arr=DB::table('goods')->where('goods_id',$goods_id)->first();
        if($arr){
            $goodsNum=$arr->goods_num;
            if($goodsNum>$num){
                DB::table('cart')->where('cart_id',$cart_id)->update(['number'=>$num]);
                echo json_encode([
                    'msg'=>0,
                    'font'=>'修改成功'
                ]);
            }else{
                DB::table('cart')->where('cart_id',$cart_id)->update(['number'=>$goodsNum]);
                echo json_encode([
                    'msg'=>0,
                    'font'=>'库存不足',
                    'count'=>$goodsNum
                ]);
            }

        }else{
            $res=DB::table('cart')->where('cart_id',$cart_id)->update(['status'=>2]);
            echo json_encode([
                'msg'=>0,
                'font'=>'删除成功'
            ]);  
        }
        
    }
    public function delcart(Request $request){
        $cart_id=$request->input('id');
        // $id = $request->session()->get('id');
        $cartid=explode(',',$cart_id);
        // print_r($cartid);die;
        foreach($cartid as $v){
            $res=DB::table('cart')->where('cart_id',$v)->update(['status'=>2]);
        }
            echo json_encode([
                'msg'=>0,
                'font'=>'删除成功'
            ]);
       
    }
    
    public function docart(Request $request){
        $goods_id=$request->input('id');
        $arr=DB::table('goods')->where('goods_id',$goods_id)->first();
        // print_r($arr);die;
        if($arr){
            $id = $request->session()->get('id');
            if(session($id)){
                echo json_encode([
                    'msg'=>1,
                    'font'=>'您没有登录'
                ]);
            }else{
                $goods_up=$arr->goods_up;
                if($goods_up!=1){
                    echo json_encode([
                        'msg'=>1,
                        'font'=>'没有此商品'
                    ]);
                }else{
                    $where=[
                        'goods_id'=>$goods_id,
                        'user_id'=>$id,
                        'status'=>1
                    ];
                    $cart= DB::table('cart')->where($where)->first();
                    if($cart){
                        $number=$cart->number;
                        $num=$number+1;
                        $goods_num=$arr->goods_num;
                        if($num>$goods_num){
                            echo json_encode([
                                'msg'=>1,
                                'font'=>'库存不足'
                            ]);
                        }else{
                            $cart= DB::table('cart')->where($where)->update(['number'=>$num]);
                            $caCount= DB::table('cart')->where('user_id',$id)->select('number')->get();
                               $num=[];
                            foreach($caCount as $k=>$v){
                                    $num[]=$v->number;
                                }
                                $count=array_sum($num);
                           
                            // print_r($cartCount);die;
                            echo json_encode([
                                'msg'=>0,
                                'font'=>'添加成功',
                               
                            ]);
                        }
                    }else{
                        $data=[];
                        $data['goods_id']=$goods_id;
                        $data['user_id']=$id;
                        $data['number']=1;
                        $data['status']=1;
                        $data['ctime']=time();
                        DB::table('cart')->insert($data);
                        echo json_encode([
                            'msg'=>0,
                            'font'=>'添加成功'
                        ]);
                    }
                   
                }
            }
        }else{
            echo json_encode([
                'msg'=>1,
                'font'=>'没有该商品'
            ]);
        }
        // return view('haitao.cart');
    }
    public function dopayment(Request $request){
       
        // $arr=DB::table('goods')->where('goods_id',$goods_id)->first();

        $id = $request->session()->get('id');
            if(session($id)){
                echo json_encode([
                    'status'=>1,
                    'msg'=>1,
                    'font'=>'您没有登录'
                ]);
            }else{
                $cart_id=$request->input('id'); 
                // print_r($cart_id);die;  
                if($cart_id==""){
                    echo json_encode([
                        'status'=>1,
                        'msg'=>1,
                        'font'=>"请选择要购买的商品"
                    ]);die;
                }            
               $carid=ltrim($cart_id,',');
               $cartid=explode(',',$carid);
               $goods_id=[];
               $goods_name=[];
               $goods_price=[];
                $goods_amount=[];
                foreach($cartid as $v){
                    $res=DB::table('cart')->join('goods','goods.goods_id','=','cart.goods_id')->where('cart_id',$v)->first();
                   $goods_id[]=$res->goods_id;
                   $g_price=$res->goods_selfprice;
                   $goods_name[]=$res->goods_name;
                   $goods_price[]=$g_price;
                   $num=$res->number;
                   $number[]=$num;
                   $goods_amount[]=$g_price*$num;
                   
                    if($res->goods_up!=1){
                         echo json_encode([
                            'status'=>1,
                            'cartid'=>$v,
                            'msg'=>1,
                            'font'=>$res->goods_name."商品已下架建议删除"
                        ]);die;
                    }else if($res->goods_num<$res->number){
                        DB::table('cart')->where('cart_id',$v)->update(['number'=>$res->goods_num]);
                        echo json_encode([
                            'status'=>1,
                            'cartid'=>$v,
                            'cartnum'=>$res->goods_num,
                            'msg'=>2,
                            'font'=>$res->goods_name."商品库存不足"
                        ]);die;
                    }
                }
                $bol='false';
                // print_r($goods_amount);die;
                $order_amount=array_sum($goods_amount);
                // echo $order_amount;die;
                //存订单
                $order_no=substr(time(),5,4).rand(10000,99999);

                $data=[];
                $data['order_no']=$order_no;
                $data['user_id']=$id;
                $data['order_amount']=$order_amount;
                $data['order_pay_type']=1;
                $data['pay_status']=1;
                $data['pay_way']=1;
                $data['status']=1;
                $data['ctime']=time();
                $orderres=DB::table('order')->insert($data);
                if($orderres){
                    $bol='true';
                }else{
                    echo json_encode([
                        'status'=>1,
                        'msg'=>1,
                        'font'=>"提交订单失败"
                    ]);die;
                }
               //存详情
              for($i=0;$i<count($goods_id);$i++){
                    $arr=[];
                    $arr['order_no']=$order_no;
                    $arr['user_id']=$id;
                    $arr['goods_id']=$goods_id[$i];
                    $arr['goods_price']=$goods_price[$i];
                    $arr['goods_name']=$goods_name[$i];
                    $arr['buy_number']=$number[$i];
                    $arr['ctime']=time();
                    $resorder_detail=DB::table('order_detail')->insert($arr);
                    if($orderres){
                        $bol='true';
                    }else{
                        echo json_encode([
                            'status'=>1,
                            'msg'=>1,
                            'font'=>"提交订单失败"
                        ]);die;
                    }
              }
                //    echo $goods_name;die;
              
                echo json_encode([
                    'status'=>1,
                    'order_no'=>$order_no,
                    'msg'=>0
                   
                ]);
            }  
        // return view('haitao.payment');
    }
    public function payment(Request $request){
        $order_no=$request->input('order_no');
        session(['order_no'=>$order_no]);
        $id = $request->session()->get('id');
        // echo $order_no;
        $data=DB::table('order_detail')->where(['order_no'=>$order_no,'user_id'=>$id])->get();
        $arr=DB::table('order')->where(['order_no'=>$order_no,'user_id'=>$id])->first();
        return view('haitao.payment',['goods'=>$data,'arr'=>$arr]);
    }
    public function isaddress(Request $request){
        // $id = $request->session()->get('id');
        $order_no=$request->input('no');
        $res=DB::table('address')->where(['order_no'=>$order_no])->first();
        if($res){
            echo json_encode([
                'msg'=>0
            ]);
        }else{
            echo json_encode([
                'font'=>'请填写地址',
                'msg'=>1
            ]);
        }
    }
    public function address(Request $request){
        // $order_no=$request->input('order');
        $order_no = $request->session()->get('order_no');
        // echo $order_no;die;
        $id = $request->session()->get('id');
        $data=DB::table('order_address')->where(['user_id'=>$id,'status'=>1])->get();
        return view('haitao.address',['data'=>$data,'order'=>$order_no]);
    }
    public function setaddress(Request $request){
        // $order_no=$request->input('order');
        $order_no = $request->session()->get('order_no');
        // echo $order_no;die;
        $address=$request->input('address');
        // echo $address;die;
        // $id = $request->session()->get('id');
        $data=[];
        $data['order_no']=$order_no;
        $data['address_id']=$address;
        $res=DB::table('address')->insert($data);
        echo json_encode([
            'order'=>$order_no,
            'msg'=>1
        ]);
    }
    public function addaddress(){
        return view('haitao.addaddress');  
    }
    public function doaddress(Request $request){
        $data=$request->input();
        $id = $request->session()->get('id');
        $data['user_id']=$id;
        $data['ctime']=time();
        $data['status']=1;
        // print_r($data);die;
        $res=DB::table('order_address')->insert($data);
        echo json_encode([
            'font'=>'添加成功',
            'msg'=>1
        ]);
    }
    public function deladdress(Request $request){
        $address=$request->input('address');
        // echo$address;die;
        $res=DB::table('order_address')->where('address_id',$address)->update(['status'=>2]);
        if($res){
             echo json_encode([
                'font'=>'删除成功',
                'msg'=>1
            ]);
        }else{
            echo json_encode([
                'font'=>'删除失败',
                'msg'=>2
            ]);
        }
       
    }
    public function upaddress(Request $request){
        $address=$request->input('address');
        $data=DB::table('order_address')->where('address_id',$address)->first();
        return view('haitao.upaddress',['data'=>$data]);
    }
    public function updoaddress(Request $request){
        $ress_id=$request->input('address_id');
        $data=$request->input();
        $id = $request->session()->get('id');
        $data['user_id']=$id;
        $data['utime']=time();
        // print_r($data);die;
        $res=DB::table('order_address')->where('address_id',$ress_id)->update($data);
        echo json_encode([
            'font'=>'修改成功',
            'msg'=>1
        ]);
    }
    public function baycart(){
        $user=DB::table('goods')->where('goods_hot',1)->offset(0)->limit(4)->get();
        return view('haitao.baycart',['user'=>$user]);
    }
}
