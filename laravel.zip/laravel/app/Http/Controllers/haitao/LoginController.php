<?php

namespace App\Http\Controllers\haitao;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
class LoginController extends Controller
{
    public function register(){
        return view('haitao.register');
    }
    public function login(){
        return view('haitao.login');
    }
    public function doregister(Request $request){
        $arr=$request->input();
        // print_r($arr);
        $pwd=$arr['pwd'];
        $phone=$arr['phone'];
        $conpwd=$arr['conpwd'];
        $code=$arr['code'];
        // echo $pwd;die;
        $data=[];
        $data['pwd']=$pwd;
        $data['name']=$phone;
        $user=DB::table('code')->where(['tel'=>$phone,'status'=>1])->orderBy('id', 'desc')->first();
        //验证验证码
        // print_r($user);
        
        if(empty($user)){
            echo json_encode(['msg'=>0,'font'=>'请输入收取验证码的手机号！']);
        }else if(time()>$user->time){
            echo json_encode(['msg'=>0,'font'=>'您的验证码过期！']);
        }else if($code!=$user->code){
            echo json_encode(['msg'=>0,'font'=>'您的验证码有误！']);
        }else{
            $id=$user->id;
            if($pwd!=$conpwd){
                echo json_encode([
                    'msg'=>0,
                    'font'=>"密码不一致"
                ]);
            }else{
                $user=DB::table('user')->where('name',$phone)->first();
                // print_r($user);
                if(!empty($user)){
                    echo json_encode([
                        'msg'=>0,
                        'font'=>"用户已注册"
                    ]);
                }else{
                    DB::table('user')->insert($data);
                    echo json_encode([
                        'msg'=>1,
                        'font'=>'注册成功'
                    ]);
                    DB::table('code')->where('id',$id)->update(['status'=>0]);
                }
            } 
 
        }
        
    }
    public function dologin(Request $request){
        $arr =$request->input();
        // print_r($arr);die;
        $user=DB::table('user')->where($arr)->first();
        if(empty($user)){
            echo json_encode([
                'msg'=>0,
                'font'=>"账号或密码错误"
            ]);
        }else{
            $id=$user->id;
            $name=$user->name;
            session(['id'=>$id,'name'=>$name]);
            // echo $request->session()->get('id');
            echo json_encode([
                'msg'=>1,
                'font'=>"登录成功"
            ]);
        }

    }
  
    public function docode(Request $request){
        $tel=$request->input('tel');
        // print_r($tel) ;
        $num=111;
        $code=100;
        // $num = rand(1000,9999);
        // //        dump($arr);exit;
        // $obj=new \send();
        // $code=$obj->show($tel,$num);
        if($code==100){
            $data=[
                'code'=>$num,
                'tel'=>$tel,
                'time'=>time()+60*60,
                'status'=>1
            ];
            
            $res=DB::table('code')->insert($data);
            echo json_encode([
                'msg'=>1,
                'font'=>'发送成功'
            ]);
        }else{
            echo json_encode([
                'msg'=>2,
                'font'=>'发送失败'
            ]);
        }
    }
    // public function t1(Request $request){
    //     $obj=new \send();
    //     $tel='18735978024';
    //     $obj->show($tel);
    // }
    public function dome(Request $request){
        return view('haitao.dome');
    }
}
