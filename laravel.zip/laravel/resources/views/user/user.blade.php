<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="/js/jquery-3.1.1.min.js"></script>
</head>
<body>
    <form method="post" action="">
    <table border=1>
        <tr>
            <td>名称</td>
            <td><input type="text"id="name" name="name"></td>
        </tr>
        <tr>
            <td>分类</td>
            <td>
                <select name="category"id="category">
                    <?php foreach($users as $k=>$v){?>
                        <option value="<?php echo $v->cata_id?>"><?php echo $v->cate_name?></option>
                    <?php }?>
                </select>
            </td>
        </tr>
        <tr>
            <td>描述</td>
            <td><textarea name="content"id="content" cols=20 rows=10></textarea></td>
        </tr>
        <tr>
            <td>是否热</td>
            <td>
                <input type="radio"class="is_hot" name="is_hot"value=1>是
                <input type="radio" class="is_hot"name="is_hot"value=2 checked>否
            </td>
        </tr>
        <tr>
            <td>上架</td>
            <td>
                <input type="radio"class="is_up" name="is_up"value=1>是
                <input type="radio"class="is_up" name="is_up"value=2 checked>否
            </td>
        </tr>
        <tr>
            <td></td>
            <td><input type="button" id="submit" value="确定"></td>
        </tr>
    </table>

    </form>
 
</body>
</html>
<script>
    $(function(){
        $("#submit").click(function(){
            // alert(11)
            var name=$("#name").val()
            var category=$("#category").val()
            var content=$("#content").val()
            var is_hot=$(".is_hot:checked").val()
            var is_up=$(".is_up:checked").val()
            // alert(is_hot)
            $.post(
                "doadd",
                {name:name,category:category,content:content,is_hot:is_hot,is_up:is_up},
                function(msg){
                    if(msg==1){
                        alert('添加成功')
                        location.href="show"
                    }else{
                        alert('添加失败')
                        location.href="add"
                    }
                }
            )
            return false 
        })
    })
</script>