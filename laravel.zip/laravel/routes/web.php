<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');

// Route::get('add','user\UserController@index');
// Route::post('doadd','user\UserController@doadd');
// Route::get('show','user\UserController@show');
// Route::post('delect','user\UserController@delect');
// Route::get('update','user\UserController@update');
// Route::post('doupdate','user\UserController@doupdate');

route::get('index','haitao\IndexController@index');
route::get('register','haitao\LoginController@register');
route::get('login','haitao\LoginController@login');
route::get('userpage','haitao\IndexController@userpage')->middleware('login');
route::post('doregister','haitao\LoginController@doregister');
route::post('dologin','haitao\LoginController@dologin');
route::post('docode','haitao\LoginController@docode');
route::get('dome','haitao\LoginController@dome');
// route::get('tel','haitao\LoginController@t1');
route::post('box','haitao\indexController@box');
route::post('goods','haitao\indexController@goods');
route::get('allshop','haitao\indexController@allshop');
route::get('show','haitao\indexController@show');
route::get('cart','haitao\indexController@cart');
route::post('docart','haitao\indexController@docart');
route::post('upcart','haitao\indexController@upcart');
route::post('delcart','haitao\indexController@delcart');
route::get('payment','haitao\indexController@payment');
route::post('dopayment','haitao\indexController@dopayment');
route::post('isaddress','haitao\indexController@isaddress');
route::get('address','haitao\indexController@address');
route::get('addaddress','haitao\indexController@addaddress');
route::post('setaddress','haitao\indexController@setaddress');
route::post('doaddress','haitao\indexController@doaddress');
route::post('deladdress','haitao\indexController@deladdress');
route::get('upaddress','haitao\indexController@upaddress');
route::post('updoaddress','haitao\indexController@updoaddress');
route::get('baycart','haitao\indexController@baycart');