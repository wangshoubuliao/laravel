<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| HeRe is wheRe you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');

// Route::get('add','user\UserController@index');
// Route::post('doadd','user\UserController@doadd');
// Route::get('show','user\UserController@show');
// Route::post('delect','user\UserController@delect');
// Route::get('update','user\UserController@update');
// Route::post('doupdate','user\UserController@doupdate');
Route::get('/','haitao\IndexController@index');
Route::get('index','haitao\IndexController@index');
Route::get('register','haitao\LoginController@register');
Route::get('login','haitao\LoginController@login');
Route::get('userpage','haitao\IndexController@userpage')->middleware('login');
Route::post('doregister','haitao\LoginController@doregister');
Route::post('dologin','haitao\LoginController@dologin');
Route::post('docode','haitao\LoginController@docode');
Route::get('dome','haitao\LoginController@dome');
// route::get('tel','haitao\LoginController@t1');
Route::post('box','haitao\IndexController@box');
Route::post('goods','haitao\IndexController@goods');
Route::get('allshop','haitao\IndexController@allshop');
Route::get('show','haitao\IndexController@show');
Route::get('cart','haitao\IndexController@cart');
Route::post('docart','haitao\IndexController@docart');
Route::post('upcart','haitao\IndexController@upcart');
Route::post('delcart','haitao\IndexController@delcart');
Route::get('payment','haitao\IndexController@payment');
Route::post('dopayment','haitao\IndexController@dopayment');
Route::post('isaddress','haitao\IndexController@isaddress');
Route::get('address','haitao\IndexController@address');
Route::get('addaddress','haitao\IndexController@addaddress');
Route::post('setaddress','haitao\IndexController@setaddress');
Route::post('doaddress','haitao\IndexController@doaddress');
Route::post('deladdress','haitao\IndexController@deladdress');
Route::get('upaddress','haitao\IndexController@upaddress');
Route::post('updoaddress','haitao\IndexController@updoaddress');
Route::get('baycart','haitao\IndexController@baycart');