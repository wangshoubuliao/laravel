<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="/js/jquery-3.1.1.min.js"></script>
</head>
<body>
    <table border=1>
        <tr>
            <td>name</td>
            <td>category</td>
            <td>content</td>
            <td>is_hot</td>
            <td>is_up</td>
            <td>操作</td>
        </tr>
      
        <!-- <div class="container"> -->
         
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <tr id="<?php echo e($v->id); ?>">
                <td class="name"><?php echo e($v->name); ?></td>
                <td class="cate"><?php echo e($v->cate_name); ?></td>
                <td><?php echo e($v->content); ?></td>
                <?php if($v->is_hot == 1): ?>
                <td>√</td>
                <?php else: ?>
                <td>×</td>
                <?php endif; ?>
                <?php if($v->is_up == 2): ?>
                <td>×</td>
                <?php else: ?>
                <td>√</td>
                <?php endif; ?>
                <td><a href="update?id=<?php echo e($v->id); ?>" class='update'>修改</a>   <a href="javascript:;"class='delect'>删除</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <!-- </div> -->
        
    </table>
    <?php echo e($users->links()); ?> 
</body>
</html>
<script>
    $(function(){
        $(document).on('click','.delect',function(){ 
           var _this=$(this)
           var id=_this.parents('tr').prop('id')
            //    alert(id)
            $.post(
                'delect',
                {id:id},
                function(msg){
                    if(msg==1){
                        alert('删除成功')
                        _this.parents('tr').remove()
                    }else{
                        alert('删除失败')
                    }
                }
            )

        })
        $(document).on('click','.name',function(){
            // alert(12)
            var _this=$(this)
            var text=_this.text()
           
            // _this.append('<input type="text" value="'+text+'">')
             _this.empty();
            _this.html("<input type='text'autofocus name='name' value="+text+">")
        })
        
        $(document).on('blur','.name',function(){
             var _this=$(this)
            var text=_this.text()
            var id=_this.parents('tr').prop('id')
            $.post(
                'up',
                {id:id,text:text},
                function(msg){
                    if(msg==1){
                        alert('修改成功')
                        
                    }else{
                        alert('修改失败')
                    }
                }
            )
        })
    })
</script>