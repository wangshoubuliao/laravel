<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="/js/jquery-3.1.1.min.js"></script>
</head>
<body>
    <form method="post" action="">
    <table border=1><input type="hidden"id="id" name="id"value="<?php echo e($user['0']->id); ?>">
        <tr>
            <td>名称</td>
            <td><input type="text"id="name" name="name"value="<?php echo e($user['0']->name); ?>"></td>
        </tr>
        <tr>
            <td>分类</td>
            <td>
                <select name="category"id="category">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($user['0']->category == $v->cata_id): ?>
                            <option value="<?php echo $v->cata_id?>"selected><?php echo $v->cate_name?></option>
                        <?php else: ?>
                            <option value="<?php echo $v->cata_id?>"><?php echo $v->cate_name?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </td>
        </tr>
        <tr>
            <td>描述</td>
            <td><textarea name="content"id="content" cols=20 rows=10><?php echo e($user['0']->content); ?></textarea></td>
        </tr>
        <tr>
            <td>是否热</td>
            <td><?php if($user['0']->is_hot == 2): ?>
                    <input type="radio"class="is_hot" name="is_hot"value=1>是
                    <input type="radio" class="is_hot"name="is_hot"value=2 checked>否
                <?php else: ?>
                    <input type="radio"class="is_hot" name="is_hot"value=1 checked>是
                    <input type="radio" class="is_hot"name="is_hot"value=2 >否
                <?php endif; ?>
                
            </td>
        </tr>
        <tr>
            <td>上架</td>
            <td><?php if($user['0']->is_up == 2): ?>
                <input type="radio"class="is_up" name="is_up"value=1>是
                <input type="radio"class="is_up" name="is_up"value=2 checked>否
                <?php else: ?>
                    <input type="radio"class="is_up" name="is_up"value=1 checked>是
                    <input type="radio" class="is_up"name="is_up"value=2 >否
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <td></td>
            <td><input type="button" id="submit" value="确定"></td>
        </tr>
    </table>

    </form>
 
</body>
</html>
<script>
    $(function(){
        $("#submit").click(function(){
            // alert(11)
            var id=$("#id").val()
            var name=$("#name").val()
            var category=$("#category").val()
            var content=$("#content").val()
            var is_hot=$(".is_hot:checked").val()
            var is_up=$(".is_up:checked").val()
            // alert(is_hot)
            $.post(
                "doupdate",
                {id:id,name:name,category:category,content:content,is_hot:is_hot,is_up:is_up},
                function(msg){
                    if(msg==1){
                        alert('修改成功')
                        location.href="show"
                    }else{
                        alert('修改失败')
                        location.href="add"
                    }
                }
            )
            return false 
        })
    })
</script>